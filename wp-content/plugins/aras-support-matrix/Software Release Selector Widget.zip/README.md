
  # Software Release Selector Widget

  This is a code bundle for Software Release Selector Widget. The original project is available at https://www.figma.com/design/eriWfIjvoPxVwAUeeImo6H/Software-Release-Selector-Widget.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  