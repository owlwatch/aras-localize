import { ReleaseWidget } from './components/ReleaseWidget';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="mb-8">Software Release Compatibility</h1>
        <ReleaseWidget />
      </div>
    </div>
  );
}
