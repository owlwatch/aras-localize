import { useState } from 'react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './ui/table';
import { Badge } from './ui/badge';
import { LayoutGrid, Table as TableIcon, CheckCircle2, AlertCircle, XCircle } from 'lucide-react';

// Mock data structure
export type SupportStatus = 'End of Life' | 'Certified' | 'Supported';

export interface Version {
  version: string;
  status: SupportStatus;
}

export interface Component {
  id: string;
  name: string;
  versions: Version[];
}

export interface Release {
  id: string;
  name: string;
  components: Component[];
}

// Mock data
const mockReleases: Release[] = [
  {
    id: 'r30',
    name: 'Release 30 | (Build 14.0.26.41200)',
    components: [
      {
        id: 'enterprise-search',
        name: 'Enterprise Search',
        versions: [
          { version: '8.5.2', status: 'Certified' },
          { version: '8.4.1', status: 'Supported' },
          { version: '8.2.0', status: 'End of Life' }
        ]
      },
      {
        id: '3d-viz',
        name: '3D Visualization',
        versions: [
          { version: '4.2.1', status: 'Certified' },
          { version: '4.1.0', status: 'Supported' }
        ]
      },
      {
        id: 'process-engine',
        name: 'Process Engine',
        versions: [
          { version: '12.8', status: 'Certified' },
          { version: '12.7', status: 'Supported' },
          { version: '12.5', status: 'End of Life' }
        ]
      },
      {
        id: 'event-handling',
        name: 'Event Handling Framework',
        versions: [
          { version: '6.0.3', status: 'Certified' },
          { version: '5.9.1', status: 'Supported' }
        ]
      },
      {
        id: 'reporting',
        name: 'Reporting',
        versions: [
          { version: '10.4', status: 'Certified' },
          { version: '10.3', status: 'Supported' },
          { version: '10.1', status: 'Supported' },
          { version: '9.8', status: 'End of Life' }
        ]
      },
      {
        id: 'oauth-registry',
        name: 'OAuth Registry',
        versions: [
          { version: '3.2.5', status: 'Certified' },
          { version: '3.1.2', status: 'Supported' }
        ]
      }
    ]
  },
  {
    id: 'r31',
    name: 'Release 31 | (Build 14.0.27.41500)',
    components: [
      {
        id: 'enterprise-search',
        name: 'Enterprise Search',
        versions: [
          { version: '8.6.0', status: 'Certified' },
          { version: '8.5.2', status: 'Supported' }
        ]
      },
      {
        id: '3d-viz',
        name: '3D Visualization',
        versions: [
          { version: '4.3.0', status: 'Certified' },
          { version: '4.2.1', status: 'Supported' }
        ]
      },
      {
        id: 'process-engine',
        name: 'Process Engine',
        versions: [
          { version: '13.0', status: 'Certified' },
          { version: '12.8', status: 'Supported' }
        ]
      },
      {
        id: 'event-handling',
        name: 'Event Handling Framework',
        versions: [
          { version: '6.1.0', status: 'Certified' },
          { version: '6.0.3', status: 'Supported' }
        ]
      },
      {
        id: 'reporting',
        name: 'Reporting',
        versions: [
          { version: '10.5', status: 'Certified' },
          { version: '10.4', status: 'Supported' },
          { version: '10.3', status: 'Supported' }
        ]
      },
      {
        id: 'oauth-registry',
        name: 'OAuth Registry',
        versions: [
          { version: '3.3.0', status: 'Certified' },
          { version: '3.2.5', status: 'Supported' },
          { version: '3.0.1', status: 'End of Life' }
        ]
      }
    ]
  },
  {
    id: 'r32',
    name: 'Release 32 | (Build 14.0.28.41847)',
    components: [
      {
        id: 'enterprise-search',
        name: 'Enterprise Search',
        versions: [
          { version: '8.7.1', status: 'Certified' },
          { version: '8.6.0', status: 'Supported' }
        ]
      },
      {
        id: '3d-viz',
        name: '3D Visualization',
        versions: [
          { version: '4.4.0', status: 'Certified' }
        ]
      },
      {
        id: 'process-engine',
        name: 'Process Engine',
        versions: [
          { version: '13.1', status: 'Certified' },
          { version: '13.0', status: 'Supported' }
        ]
      },
      {
        id: 'event-handling',
        name: 'Event Handling Framework',
        versions: [
          { version: '6.2.0', status: 'Certified' },
          { version: '6.1.0', status: 'Supported' },
          { version: '6.0.3', status: 'Supported' }
        ]
      },
      {
        id: 'reporting',
        name: 'Reporting',
        versions: [
          { version: '11.0', status: 'Certified' },
          { version: '10.5', status: 'Supported' }
        ]
      },
      {
        id: 'oauth-registry',
        name: 'OAuth Registry',
        versions: [
          { version: '3.4.0', status: 'Certified' },
          { version: '3.3.0', status: 'Supported' }
        ]
      }
    ]
  }
];

// Helper component for status badge
function StatusBadge({ status }: { status: SupportStatus }) {
  const config = {
    'Certified': {
      className: 'bg-green-100 text-green-800 hover:bg-green-100',
      icon: CheckCircle2
    },
    'Supported': {
      className: 'bg-blue-100 text-blue-800 hover:bg-blue-100',
      icon: AlertCircle
    },
    'End of Life': {
      className: 'bg-red-100 text-red-800 hover:bg-red-100',
      icon: XCircle
    }
  };

  const { className, icon: Icon } = config[status];

  return (
    <Badge className={className}>
      <Icon className="size-3 mr-1" />
      {status}
    </Badge>
  );
}

// Card view component
function VersionCards({ component }: { component: Component }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {component.versions.map((version, index) => (
        <div
          key={`${version.version}-${index}`}
          className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
        >
          <div className="flex items-start justify-between mb-3">
            <div>
              <p className="text-xs text-gray-500 mb-1">Version</p>
              <p className="text-lg">{version.version}</p>
            </div>
            <StatusBadge status={version.status} />
          </div>
          <div className="pt-3 border-t border-gray-100">
            <p className="text-xs text-gray-500">{component.name}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

// Table view component
function VersionTable({ component }: { component: Component }) {
  return (
    <div className="border border-gray-200 rounded-lg overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Component</TableHead>
            <TableHead>Version</TableHead>
            <TableHead>Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {component.versions.map((version, index) => (
            <TableRow key={`${version.version}-${index}`}>
              <TableCell>{component.name}</TableCell>
              <TableCell>{version.version}</TableCell>
              <TableCell>
                <StatusBadge status={version.status} />
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

export function ReleaseWidget() {
  const [selectedRelease, setSelectedRelease] = useState<Release>(mockReleases[0]);
  const [selectedComponents, setSelectedComponents] = useState<Component[]>([]);
  const [viewMode, setViewMode] = useState<'table' | 'cards'>('cards');

  const handleReleaseChange = (releaseId: string) => {
    const release = mockReleases.find(r => r.id === releaseId);
    if (release) {
      setSelectedRelease(release);
      setSelectedComponents([]);
    }
  };

  const toggleComponent = (component: Component) => {
    setSelectedComponents(prev => {
      const isSelected = prev.some(i => i.id === component.id);
      if (isSelected) {
        return prev.filter(i => i.id !== component.id);
      } else {
        return [...prev, component];
      }
    });
  };

  const isComponentSelected = (componentId: string) => {
    return selectedComponents.some(i => i.id === componentId);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="space-y-6">
        {/* Controls section */}
        <div className="space-y-4">
          {/* Release selector and view toggle */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex-1 max-w-xs">
              <label className="block text-sm mb-2 text-gray-700">
                Select Release
              </label>
              <Select value={selectedRelease.id} onValueChange={handleReleaseChange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {mockReleases.map((release) => (
                    <SelectItem key={release.id} value={release.id}>
                      {release.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* View mode toggle */}
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-700 mr-2">View:</span>
              <button
                onClick={() => setViewMode('cards')}
                className={`p-2 rounded-md transition-colors ${
                  viewMode === 'cards'
                    ? 'bg-blue-100 text-blue-600'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
                aria-label="Card view"
              >
                <LayoutGrid className="size-5" />
              </button>
              <button
                onClick={() => setViewMode('table')}
                className={`p-2 rounded-md transition-colors ${
                  viewMode === 'table'
                    ? 'bg-blue-100 text-blue-600'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
                aria-label="Table view"
              >
                <TableIcon className="size-5" />
              </button>
            </div>
          </div>

          {/* Component list */}
          <div>
            <label className="block text-sm mb-2 text-gray-700">
              Select Component
            </label>
            <div className="flex flex-wrap gap-2">
              {selectedRelease.components.map((component) => (
                <button
                  key={component.id}
                  onClick={() => toggleComponent(component)}
                  className={`px-4 py-2 rounded-md text-sm transition-colors ${
                    isComponentSelected(component.id)
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {component.name}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Results section */}
        <div>
          {selectedComponents.length > 0 ? (
            <div className="space-y-4">
              {/* Results header */}
              <div className="flex items-center justify-between border-b border-gray-200 pb-3">
                <div>
                  <h3 className="text-gray-900">Selected Components</h3>
                  <p className="text-sm text-gray-500 mt-1">
                    {selectedComponents.length} component{selectedComponents.length !== 1 ? 's' : ''} selected
                  </p>
                </div>
                
                {/* Status legend */}
                <div className="hidden md:flex items-center gap-4 text-xs">
                  <div className="flex items-center gap-1.5">
                    <div className="size-3 rounded-full bg-green-500"></div>
                    <span className="text-gray-600">Certified</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="size-3 rounded-full bg-blue-500"></div>
                    <span className="text-gray-600">Supported</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="size-3 rounded-full bg-red-500"></div>
                    <span className="text-gray-600">End of Life</span>
                  </div>
                </div>
              </div>
              
              {/* Results content */}
              {viewMode === 'cards' && (
                <div className="space-y-6">
                  {selectedComponents.map((component) => (
                    <div key={component.id}>
                      <h4 className="text-sm text-gray-700 mb-3">{component.name}</h4>
                      <VersionCards component={component} />
                    </div>
                  ))}
                </div>
              )}
              {viewMode === 'table' && (
                <div className="space-y-6">
                  {selectedComponents.map((component) => (
                    <div key={component.id}>
                      <h4 className="text-sm text-gray-700 mb-3">{component.name}</h4>
                      <VersionTable component={component} />
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-16 bg-gray-50 rounded-lg border-2 border-dashed border-gray-200">
              <div className="max-w-sm mx-auto">
                <div className="inline-flex items-center justify-center size-16 bg-blue-100 rounded-full mb-4">
                  <LayoutGrid className="size-8 text-blue-600" />
                </div>
                <p className="text-gray-600 mb-2">Select a component to view compatibility</p>
                <p className="text-sm text-gray-400">
                  Choose from the available components above to see version details and support status
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
